def hello_world(request):
    # Vérifier si la méthode de la requête est GET
    if request.method == 'GET':
        # Retourner "1" pour la valeur 1 et "2" pour la valeur 2
        value = request.args.get('value', '')
        if value == '1':
            return "1"
        elif value == '2':
            return "2"

    # Retourner un message d'erreur pour les autres cas
    return "Invalid input. Please send '1' or '2' using a GET request."